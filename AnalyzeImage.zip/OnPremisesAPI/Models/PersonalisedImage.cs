﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnPremisesAPI.Models
{
    public class PersonalisedImage
    {
        public string ImageBase64 { get; set; }
    }
}
